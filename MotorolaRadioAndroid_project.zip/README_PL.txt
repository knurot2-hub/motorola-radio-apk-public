MOTOROLA RADIO – projekt Android

To jest pierwsza wersja interaktywnego wyglądu radia na podstawie przesłanej fotografii.
Działa: pokrętło głośności (symulacja), wybór kanałów, przyciski funkcyjne, menu,
skanowanie (symulacja), alarm testowy i przytrzymywany PTT (wskaźnik na ekranie).

UWAGA:
- PTT w tej wersji jest tylko demonstracją interfejsu. Nie wysyła dźwięku do Discorda
  ani do innych użytkowników.
- Kanały są lokalnie symulowane. Nie są kanałami radiowymi ani Discorda.
- Aplikacja nie łączy się z prawdziwymi częstotliwościami radiowymi.

Jak zbudować APK:
1. Otwórz folder MotorolaRadio w Android Studio.
2. Poczekaj na synchronizację Gradle.
3. Wybierz Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK znajdziesz w app/build/outputs/apk/debug/app-debug.apk.

Projekt wymaga Android SDK 35 i Gradle pobranego przez Android Studio.
